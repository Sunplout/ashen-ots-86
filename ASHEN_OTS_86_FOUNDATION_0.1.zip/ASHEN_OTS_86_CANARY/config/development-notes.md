# Development configuration notes

Use Canary's own `config.lua.dist` and Docker quickstart as the source of truth. Do not replace them with generic TFS 0.4 settings.

For local testing:
- follow `docker/quickstart-for-beginners.md` in the Canary repository;
- keep DB private to the Docker network;
- use local-only test credentials;
- set the server IP to a numeric reachable IPv4 for the classic 8.60 character-list format when required;
- ensure the legacy 8.60 game port is mapped correctly (Canary docs describe automatic allocation; explicit mapping is easier in container setups).

Never commit `.env`, real passwords, private keys or production IPs.
