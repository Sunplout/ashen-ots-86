# Client compatibility — 8.60

Do not assume that any random 8.60 client download will connect.

Canary's current multiprotocol documentation describes a classic 8.60 wire profile. It also explains that:
- the official CipSoft private RSA key is not available to Canary, so an unmodified official client is not automatically compatible;
- the documented supported deployment uses a compatible client and an extended 8.60 asset package;
- the item IDs in the client asset package must match the server's item IDs unless an item mapper is used;
- account login is performed first, and the character list supplies the game port.

For this project, use only a client build and assets whose distribution rights and provenance are clear. Do not bundle proprietary Tibia files in this repository.
