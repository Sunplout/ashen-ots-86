# Ashen OTS 8.60 — Technical architecture

## Runtime

```text
[8.60-compatible PC client]
          |
   Login port 7171
          |
 [Canary login protocol]
          |
  character list returns
  profile-specific game port
          |
 [Canary 8.60 game protocol]
          |
  +-------+--------+
  |                |
[Lua content]  [MariaDB]
  |                |
[OTBM map]    accounts/players/
              houses/guilds/storage
```

## Components

| Layer | Choice | Purpose |
|---|---|---|
| Server core | OpenTibiaBR Canary | Game loop, networking, combat, world |
| Protocol | CipSoft 8.60 legacy profile | Classic 8.60 packet contract |
| Client | compatible 8.60 client package | Rendering and input |
| Content | Lua | NPCs, monsters, quests, spells, actions |
| World | OTBM + spawn data | Town, roads, caves, hunting zones |
| Database | MariaDB | Account and character persistence |
| Local deployment | Canary Docker quickstart | Repeatable development environment |
| Map editor | Remere's Map Editor (compatible build) | OTBM authoring |

## 8.60 compatibility gotcha
Canary documentation says the 8.60 profile is a classic wire-layout profile, but that does **not** mean an unmodified official CipSoft client can connect. Canary does not possess CipSoft's private RSA key. The documented 8.60 deployment uses a compatible client setup and an extended asset package whose item IDs match the server. A truly vanilla 8.60 asset set needs item mapping or an explicit world-entry block. The client and asset route must be selected and tested before promising compatibility.

Canary's multiprotocol documentation describes:
- `Cipsoft860Vanilla`
- `Cipsoft860ExtendedAssets`
- `Cipsoft860CanaryExtended`
- legacy 8.60 game port (default auto-selection or explicitly configured)
- account login first on port 7171; the character list supplies the correct game port.

## MVP gameplay slice
- One safe town: temple, depot, general shop, NPC guide.
- One beginner field and one cave.
- Three original low-level creatures.
- Basic melee, loot, corpse decay, respawn.
- One short quest.
- Two test accounts visible to each other.
- Persistence across logout/restart.

## Security / operations
- Never expose MariaDB to the public internet.
- Use unique secrets and least-privilege DB credentials.
- Expose only documented login/game ports.
- Keep database and world backups outside the container.
- Test restoring backups.
- Keep staff tools restricted and log moderation actions.
