# Build plan

## Phase A — establish the engine
- Clone `https://github.com/opentibiabr/canary`.
- Read the current Docker beginner quickstart.
- Record the selected commit SHA in `ENGINE_VERSION.txt`.
- Run the upstream quickstart locally in Codespaces/Linux.
- Confirm DB health and server logs.

## Phase B — 8.60 client handshake
- Read Canary's `docs/systems/multiprotocol.md`.
- Select the supported 8.60 profile and correct asset/client package.
- Configure the numeric IPv4 address if required by the classic character-list layout.
- Verify login on account port 7171 and then the returned 8.60 game port.
- Test with two separate clients.
- Do not patch RSA or client executables using untrusted downloads.

## Phase C — content
- Build a small original OTBM map.
- Add spawn zones, temple and depot.
- Add original NPC scripts and creature definitions.
- Tune experience, loot, skills and spawn rates.
- Add a quest with server-side storage.

## Phase D — release readiness
- Load test and crash recovery.
- Database backup/restore test.
- Firewall, monitoring, moderation and abuse reporting.
- Legal review, privacy notice and hosting plan before public beta.
