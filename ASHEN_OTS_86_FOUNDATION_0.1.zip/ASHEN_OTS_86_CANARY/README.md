# ASHEN OTS 8.60 — Foundation 0.1

A project scaffold for a classic 8.60-style Open Tibia server using the maintained **OpenTibiaBR Canary** engine.

**Important:** this package is not a compiled/running server. It contains the architecture, setup checklist, configuration notes and content plan. The next step is to clone and pin a Canary revision, then boot its documented Docker quickstart and verify the 8.60 profile with a compatible client.

## Why Canary?
The current Canary documentation explicitly describes legacy 8.60 protocol profiles, including `Cipsoft860Vanilla`, `Cipsoft860ExtendedAssets` and `Cipsoft860CanaryExtended`. It also documents the required legacy game port and client asset compatibility. This makes it a more credible maintained starting point than blindly choosing an old TFS 0.4 fork.

## Project decisions
- Game style: classic Tibia 8.6 / 8.60.
- Engine: OpenTibiaBR Canary, with the 8.60 runtime profile.
- Server logic: C++ core + Lua content.
- Database: MariaDB (via Canary's supported Docker quickstart).
- Map: original OTBM map, created for this project.
- Client: 8.60-compatible client package prepared according to Canary's current compatibility instructions.
- Initial platform: PC. Android is a later client project, not part of MVP.

## First milestone
1. Clone Canary and pin a specific commit.
2. Start the official local Docker quickstart.
3. Configure the 8.60 legacy profile and its game port.
4. Prepare a compatible client/assets package.
5. Log in with a test account.
6. Test movement, logout/relogin, and two simultaneous clients.
7. Add a small original town and beginner hunting area.

## Legal boundary
Do not redistribute CipSoft's proprietary client, original Tibia sprites, maps, sounds or other copyrighted assets without permission. A protocol-compatible server emulator does not grant rights to those assets or to the Tibia trademark. Use original or properly licensed content, and get legal advice before a public or monetized launch.

## Status
Foundation only. No Canary binary has been built or started here; no database has been initialized; no client login has been tested. Those steps require a Linux/Docker environment (for example, a GitHub Codespace) and an exact pinned source revision.
