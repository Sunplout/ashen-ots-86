Put original OTBM map and spawn files here. Do not copy commercial Tibia map data or third-party maps without explicit redistribution rights.
